<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="home.css">
    <title>Home</title>

</head>

<body>
    <h1>Relp!</h1>
<div class="box box-login">
  <a href="login.php">Login</a>
</div>

<div class="box box-fornecedor">
  <a href="login_fornecedor.php">Acesso Fornecedor</a>
</div>

<div class="box box-cadastro">
  <a href="formulario.php">Cadastro</a>
</div>

<h3>RELP!<br>
FOR YOUR COMPANY</h3>

<div class="Quem">
    <!-- Botão que leva até a div "info" -->
    <a href="#info" class="botaoQ">Quem somos</a>
  </div class="boxDoQuemsomos">
    <div>
      <div id="info" class="conteudo">
      <h2>Quem somos?</h2>
      <p>Como a Streamline pode te ajudar via RELP!</p>
    </div>

    <div class="imagem">
      <img src="img/logostreamline.png">
    </div>
  </div>

  <div class="Servicos">
    <!-- Botão que leva até a div "info" -->
    <a href="#info2" class="botaoS">Serviços</a>
  </div>

  <div id="info2" class="conteudo2">
    <h2>Planos disponíveis para compra</h2>
    <p>Pensados de forma acessível para atender suas principais necessidades de forma <br>prática e democratica.</p>
  </div>
<div class="FAQ">
    <!-- Botão que leva até a div "info" -->
    <a href="#info3" class="botaoF">FAQ</a>
  </div>

  <div id="info3" class="conteudo3">
    <h2>isso aq</h2>
    <p>vai ser um rodapé</p>
  </div>


</body>
</html>